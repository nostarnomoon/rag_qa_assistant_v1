import json
import os

from openai import OpenAI
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity



def load_json(file_path):
    with open(file_path,'r',encoding="UTF-8") as f:
        chunks = json.load(f)
    return chunks

def build_corpus(chunks):
    return [chunk["text"] for chunk in chunks]

def build_retrieval(chunks):
    #中文检索最好加上analyzer="char", ngram_range=(2, 4)这一段
    vectorizer = TfidfVectorizer(
        analyzer="char",
        ngram_range=(2, 4)
    )
    corpus = build_corpus(chunks)
    chunk_matrix = vectorizer.fit_transform(corpus)
    return vectorizer,chunk_matrix

def retrieval_top_k(question, chunks, vectorizer, chunk_matrix, top_k=3):
    question_matrix = vectorizer.transform([question])

    scores = cosine_similarity(question_matrix,chunk_matrix)[0]

    top_indices = scores.argsort()[::-1][:top_k]
    result = []

    for idx in top_indices:
        chunk = chunks[idx]
        result.append({
            "source":chunk["source"],
            "chunk_id":chunk["chunk_id"],
            "text":chunk["text"],
            "score":float(scores[idx])
        })
    return result

def build_context(top_chunks):
    context_parts = []
    for i,chunk in enumerate(top_chunks,start=1):
        context_parts.append(
            f"[参考片段{i}]\n"
            f"来源：{chunk['source']}\n"
            f"chunk编号:{chunk['chunk_id']}\n "
            f"相似度：{chunk['score']:.4f}\n"
            f"内容：{chunk['text']}\n"
        )
    return "\n".join(context_parts)

def call_llm(question,context,requirement):
    try:
        client = OpenAI(
            api_key=os.getenv("DEEPSEEK_API_KEY"),
            base_url=os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
        )
        system_prompt = """
            你是一位知识库问答助手。
            请优先依据给定的参考资料回答问题，不要编造参考资料中没有的信息。
            如果参考资料不足以支持完整回答，请明确说明“参考资料不足”。
            回答使用中文，尽量简洁清楚。
            """
        if requirement:
            user_prompt = f"""请根据下面参考资料回答问题。
            问题：
        {question}
            参考资料：
        {context}
            要求：
        {requirement}
                    """
        else:
            user_prompt = f"""请根据下面参考资料回答问题。
            问题：
        {question}
        参考资料：
        {context}
                            """
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.3,
            max_tokens=300
        )
        answer = response.choices[0].message.content
        return answer
    except Exception as e:
        return f"调用LLM失败：{e}"


def main():
    question = input("请输入问题:")
    if not question:
        print("问题不能为空")
        return
    requirement = input("请输入额外要求（可回车跳过）：").strip()
    file_path = "chunks.json"
    chunks = load_json(file_path)
    vectorizer,chunk_matrix = build_retrieval(chunks)
    top_k_retrieval = retrieval_top_k(question,chunks,vectorizer,chunk_matrix,top_k=3)
    context = build_context(top_k_retrieval)
    answer = call_llm(question,context,requirement)

    print("\n=====结果=====")
    print("\n==回答==\n", answer)
    print("\n==参考片段==\n")
    for i, item in enumerate(top_k_retrieval, start=1):
        print(f"\n--- 参考片段 {i} ---")
        print(f"来源文件: {item['source']}")
        print(f"Chunk 编号: {item['chunk_id']}")
        print(f"相似度分数: {item['score']:.4f}")
        print("内容:")
        print(item["text"])
    return

if __name__ == "__main__":
    main()




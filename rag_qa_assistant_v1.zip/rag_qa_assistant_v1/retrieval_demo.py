import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def load_chunks(json_path="chunks.json"):
    """
    读取 chunks.json
    要求每个 chunk 至少有：
    - source
    - chunk_id
    - text
    """
    with open(json_path, "r", encoding="utf-8") as f:
        chunks = json.load(f)
    return chunks


def build_corpus(chunks):
    """提取所有 chunk 的文本"""
    return [chunk["text"] for chunk in chunks]


def build_retriever(chunks):
    """
    构建检索器：
    - 中文更适合用字符级 n-gram
    """
    corpus = build_corpus(chunks)

    vectorizer = TfidfVectorizer(
        analyzer="char",
        ngram_range=(2, 4)
    )

    chunk_matrix = vectorizer.fit_transform(corpus)
    return vectorizer, chunk_matrix


def retrieve_top_k(question, chunks, vectorizer, chunk_matrix, top_k=3):
    """
    用 TF-IDF + 余弦相似度检索最相关的 top-k chunk
    """
    question_vector = vectorizer.transform([question])
    scores = cosine_similarity(question_vector, chunk_matrix)[0]

    top_indices = scores.argsort()[::-1][:top_k]

    results = []
    for idx in top_indices:
        results.append({
            "source": chunks[idx]["source"],
            "chunk_id": chunks[idx]["chunk_id"],
            "text": chunks[idx]["text"],
            "score": float(scores[idx])
        })

    return results


def main():
    chunks = load_chunks("chunks.json")
    vectorizer, chunk_matrix = build_retriever(chunks)

    question = input("请输入你的问题：").strip()
    if not question:
        print("问题不能为空")
        return

    top_results = retrieve_top_k(
        question=question,
        chunks=chunks,
        vectorizer=vectorizer,
        chunk_matrix=chunk_matrix,
        top_k=3
    )

    # 如果最高分也很低，提示用户
    if top_results and top_results[0]["score"] < 0.05:
        print("\n没有找到明显相关的内容，下面返回的是相对最接近的片段：\n")

    print("\n===== 检索结果 Top-3 =====\n")
    for i, item in enumerate(top_results, start=1):
        print(f"--- Top {i} ---")
        print(f"来源文件: {item['source']}")
        print(f"Chunk 编号: {item['chunk_id']}")
        print(f"相似度分数: {item['score']:.4f}")
        print("Chunk 内容:")
        print(item["text"])
        print()


if __name__ == "__main__":
    main()
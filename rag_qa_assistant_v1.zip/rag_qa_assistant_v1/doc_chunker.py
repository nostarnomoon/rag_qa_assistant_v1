import json
from pathlib import Path


def read_file(file_path):#
    "读取内容"
    with open(file_path,"r",encoding="UTF-8") as f:
        return f.read()

def clean_text(text):#
    "去掉空白行"
    lines = text.splitlines()#不保留换行符
    cleaned_lines = [line.strip() for line in lines if line.strip()]#strip为移除首尾空白
    return "\n".join(cleaned_lines)

def split_long_text(text,chunk_size=300,overlap=60):
    #对过长文本进行带重叠切分
    chunks =[]
    start = 0
    step = chunk_size - overlap
    if step <= 0:
        raise ValueError("chunk_size 必须大于 overlap")

    while start < len(text):
        chunk = text[start:start + chunk_size]
        chunks.append(chunk)
        start += step

    return chunks

def split_into_chunks(text,chunk_size,overlap=60):
    "按固定长度切分文本，此处采用最简单的字符数来切分"
    paragraphs = text.split("\n")
    chunks =[]
    current_chunk = ""

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        #如果单个段落本身就太长，先把已有的chunk保存
        if len(para)>chunk_size:
            if current_chunk:
                chunks.append(current_chunk)
                current_chunk=""
            sub_chunks = split_long_text(para,chunk_size=chunk_size,overlap=overlap)
            chunks.extend(sub_chunks)
            continue
        #如果拼接后还不超长，就继续拼
        if len(current_chunk)+len(para)+1<=chunk_size:
            if current_chunk:
                current_chunk+="\n"+para
            else:
                current_chunk=para
        else:
            chunks.append(current_chunk)
            current_chunk = para

    if current_chunk:
        chunks.append(current_chunk)
    return chunks

def build_chunks(file_paths,chunk_size):
    "处理多个文件，生成统一的chunk列表"
    "chunk包含：-source：来源文件名；-chunk_id：当前文件中第几个chunk；-text：chunk内容"
    all_chunks = []
    for file_path in file_paths:
        raw_text = read_file(file_path)
        cleaned_text = clean_text(raw_text)
        chunks = split_into_chunks(cleaned_text,chunk_size = chunk_size)
        for i,chunk_text in enumerate(chunks):
            chunk_data = {
                "source":Path(file_path).name,#此处使用Path是提取文件路径的末尾
                "chunk_id":i,
                "text":chunk_text
            }
            all_chunks.append(chunk_data)
    return all_chunks

def save_chunks(chunks,output_path = "chunks.json"):
    "保存为json文件"
    with open(output_path,'w',encoding="UTF-8") as f:
        json.dump(chunks,f,ensure_ascii=False,indent=2)


if __name__ == "__main__":
    file_paths =[
        "day5 note.md",
        "day7 note.md"
    ]
    chunks = build_chunks(file_paths,chunk_size=300)
    save_chunks(chunks,output_path="chunks.json")

    print(f"共生成{len(chunks)}个chunks，已保存到chunks.json")

